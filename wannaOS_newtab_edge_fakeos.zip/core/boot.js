/**
 * WannaOS — Boot Sequence + OS Namespace
 */

// ===== MAIN NAMESPACE =====
window.WannaOS = {
  boot:    null,
  taskbar: null,
  desktop: null,
  apps:    null,
  wm:      null,

  // Notifications
  notify(title, body, duration = 4000) {
    const area = document.getElementById('notifArea');
    const el = document.createElement('div');
    el.className = 'notif';
    el.innerHTML = `
      <div class="notif-title">
        <span class="notif-close" onclick="this.closest('.notif').remove()">✕</span>
        ${title}
      </div>
      <div>${body}</div>
    `;
    area.prepend(el);
    setTimeout(() => {
      el.style.transition = 'opacity 0.4s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    }, duration);
  },

  // BSOD
  triggerBSOD() {
    const bsod = document.getElementById('bsodScreen');
    const pct = document.getElementById('bsodPct');
    bsod.classList.remove('hidden');
    let n = 0;
    const t = setInterval(() => {
      n += Math.floor(Math.random() * 8) + 1;
      if (n >= 100) { n = 100; clearInterval(t); }
      pct.textContent = `Dumping physical memory to disk: ${n}`;
    }, 120);
    setTimeout(() => {
      bsod.classList.add('hidden');
      WannaOS.notify('💥 BSOD Recovered', 'System recovered from critical error.', 5000);
    }, 8000);
  },
};

// ===== BOOT MODULE =====
WannaOS.boot = (() => {
  const STEPS = [
    { pct: 8,  text: 'Initializing kernel...' },
    { pct: 18, text: 'Loading WannaCry payload...' },
    { pct: 28, text: 'Scanning for vulnerabilities...' },
    { pct: 42, text: 'Exploiting SMB (MS17-010)...' },
    { pct: 55, text: 'Encrypting user files...' },
    { pct: 66, text: 'Establishing C2 connection...' },
    { pct: 76, text: 'Loading desktop environment...' },
    { pct: 85, text: 'Starting taskbar...' },
    { pct: 92, text: 'Mounting filesystem...' },
    { pct: 100, text: 'Done. Welcome to WannaOS.' },
  ];

  function start() {
    // Wire up modules
    WannaOS.taskbar = WannaTaskbar;
    WannaOS.desktop = WannaDesktop;
    WannaOS.apps    = WannaApps;
    WannaOS.wm      = WannaWM;

    // Register apps
    WannaApps.register('decryptor', { open: WannaDecryptor.open });
    WannaApps.register('terminal',  { open: WannaTerminal.open });
    WannaApps.register('explorer',  { open: WannaExplorer.open });
    WannaApps.register('notepad',   { open: WannaNotepad.open });
    WannaApps.register('browser',   { open: WannaBrowser.open });

    // Run boot sequence
    runBootSteps(0);
  }

  function runBootSteps(idx) {
    const fill   = document.getElementById('bootFill');
    const status = document.getElementById('bootStatus');

    if (idx >= STEPS.length) {
      finishBoot();
      return;
    }

    const step = STEPS[idx];
    fill.style.width = step.pct + '%';
    status.textContent = step.text;

    const delay = idx === 0 ? 300 : 350 + Math.random() * 200;
    setTimeout(() => runBootSteps(idx + 1), delay);
  }

  function finishBoot() {
    const bootScreen = document.getElementById('bootScreen');
    const desktop    = document.getElementById('desktop');

    setTimeout(() => {
      bootScreen.style.transition = 'opacity 0.6s';
      bootScreen.style.opacity = '0';

      setTimeout(() => {
        bootScreen.classList.add('hidden');
        desktop.classList.remove('hidden');

        WannaTaskbar.init();
        WannaDesktop.init();

        // Auto-open WannaDecryptor after slight delay
        setTimeout(() => WannaApps.openApp('decryptor'), 600);

        // Schedule fake notifications
        scheduleNotifications();

        // Start fake virus scan notification
        setTimeout(() => {
          WannaOS.notify('🦠 Virus Active', '14 machines encrypted successfully.', 6000);
        }, 3000);

      }, 600);
    }, 400);
  }

  function scheduleNotifications() {
    const notifs = [
      { delay: 12000, title: '🔐 Encryption Complete', body: 'All 1,289 files encrypted.' },
      { delay: 25000, title: '💰 Payment Reminder', body: 'You have not paid yet. Price increases in 3 days.' },
      { delay: 40000, title: '📡 C2 Connection', body: 'Connected to tor2web gateway.' },
      { delay: 60000, title: '⚠️ Warning', body: 'Decryption key will be destroyed in 6 days.' },
      { delay: 90000, title: '🔒 New Files Encrypted', body: 'USB drive detected. Encrypting new files...' },
    ];

    notifs.forEach(n => {
      setTimeout(() => WannaOS.notify(n.title, n.body, 6000), n.delay);
    });
  }

  return { start };
})();
