/**
 * WannaOS — File Explorer App
 */

window.WannaExplorer = (() => {

  function open() {
    let cwd = 'C:';

    const el = document.createElement('div');
    el.className = 'app-explorer';
    el.innerHTML = `
      <div class="exp-toolbar">
        <button class="exp-btn" id="expBack">◀ Back</button>
        <button class="exp-btn" id="expUp">▲ Up</button>
        <input class="exp-path" id="expPath" value="C:" readonly>
        <button class="exp-btn" id="expRefresh">↻</button>
      </div>
      <div class="exp-body">
        <div class="exp-sidebar" id="expSidebar"></div>
        <div class="exp-main" id="expMain"></div>
      </div>
      <div class="exp-status" id="expStatus">Ready</div>
    `;

    WannaWM.open({
      id: 'explorer',
      title: '📁 File Explorer',
      icon: '📁',
      width: 680,
      height: 460,
      mount: el,
    });

    const sidebar = el.querySelector('#expSidebar');
    const main    = el.querySelector('#expMain');
    const path    = el.querySelector('#expPath');
    const status  = el.querySelector('#expStatus');

    // Sidebar quick links
    const quickLinks = [
      { label: '🖥️ C:\\', path: 'C:' },
      { label: '🖥️ Desktop', path: 'C:/Desktop' },
      { label: '📄 Documents', path: 'C:/Documents' },
      { label: '⚙️ System32', path: 'C:/System32' },
      { label: '👤 Users', path: 'C:/Users' },
      { label: '🔒 WNCRYPT', path: 'C:/WNCRYPT' },
      { label: '🪟 Windows', path: 'C:/Windows' },
    ];

    quickLinks.forEach(link => {
      const div = document.createElement('div');
      div.className = 'exp-tree-item';
      div.textContent = link.label;
      div.addEventListener('click', () => navigate(link.path));
      sidebar.appendChild(div);
    });

    function navigate(newPath) {
      const items = WannaFS.ls(newPath);
      if (!items) {
        status.textContent = `Cannot open: ${newPath}`;
        return;
      }

      cwd = newPath;
      path.value = newPath.replace(/\//g, '\\');
      main.innerHTML = '';

      // Update sidebar active
      sidebar.querySelectorAll('.exp-tree-item').forEach(e => {
        e.classList.toggle('active', e.textContent.includes(newPath.split('/').pop()));
      });

      if (items.length === 0) {
        main.innerHTML = '<div style="padding:20px;color:#662222;font-size:12px;">This folder is empty.</div>';
        status.textContent = '0 items';
        return;
      }

      items.forEach(item => {
        const div = document.createElement('div');
        div.className = 'exp-item';
        div.innerHTML = `
          <div class="exp-item-icon">${item.icon}</div>
          <div class="exp-item-name">${item.name}</div>
        `;

        div.addEventListener('click', (e) => {
          main.querySelectorAll('.exp-item').forEach(i => i.classList.remove('selected'));
          div.classList.add('selected');
          status.textContent = `Selected: ${item.name}`;
          e.stopPropagation();
        });

        div.addEventListener('dblclick', () => {
          if (item.type === 'dir') {
            navigate(`${cwd}/${item.name}`);
          } else {
            openFile(`${cwd}/${item.name}`, item.name);
          }
        });

        main.appendChild(div);
      });

      status.textContent = `${items.length} items`;
    }

    function openFile(filePath, name) {
      const content = WannaFS.read(filePath);
      if (content === null) return;

      const textEl = document.createElement('div');
      textEl.style.cssText = 'height:100%;display:flex;flex-direction:column;background:#0d0000;';
      textEl.innerHTML = `
        <div style="padding:4px 10px;background:#0a0000;border-bottom:1px solid #330000;font-size:11px;color:#882222;font-family:var(--font-mono)">${name}</div>
        <textarea readonly style="flex:1;background:#000;color:#ff4444;border:none;outline:none;padding:12px;font-family:'Share Tech Mono',monospace;font-size:12px;resize:none;line-height:1.7">${content}</textarea>
      `;

      WannaWM.open({
        id: `file_${name}`,
        title: `📄 ${name}`,
        icon: '📄',
        width: 480,
        height: 320,
        mount: textEl,
      });
    }

    el.querySelector('#expBack').addEventListener('click', () => {
      const parent = cwd.split('/').slice(0, -1).join('/') || 'C:';
      if (parent !== cwd) navigate(parent);
    });

    el.querySelector('#expUp').addEventListener('click', () => {
      const parent = cwd.split('/').slice(0, -1).join('/') || 'C:';
      navigate(parent);
    });

    el.querySelector('#expRefresh').addEventListener('click', () => navigate(cwd));

    main.addEventListener('click', () => {
      main.querySelectorAll('.exp-item').forEach(i => i.classList.remove('selected'));
    });

    navigate('C:');
  }

  return { open };
})();
