/**
 * WannaOS — Terminal App
 */

window.WannaTerminal = (() => {

  const SEARCH_ENGINES = {
    d: 'https://duckduckgo.com/?q=',
    g: 'https://www.google.com/search?q='
  };

  const DEFAULT_ENGINE = 'd';

  const BANNER = [
    '  __        __         _  ___  ____',
    '  \\ \\      / /_ _ _ _| |/ _ \\/ ___|',
    "   \\ \\ /\\ / / _` | '_| | | | \\___ \\",
    '    \\ V  V / (_| | | | | |_| |___) |',
    '     \\_/\\_/ \\__,_|_| |_|\\___/|____/',
    '',
    '  WannaOS Terminal v2.0 — Type "help" for commands',
    '  Search:',
    '    d hello   → DuckDuckGo',
    '    g hello   → Google',
    '',
  ];

  const COMMANDS = {

    help() {
      return [
        { t: 'info', v: 'Commands:' },
        { t: 'out', v: 'help' },
        { t: 'out', v: 'cls' },
        { t: 'out', v: 'exit' },
        { t: 'out', v: 'd [query]  → DuckDuckGo search' },
        { t: 'out', v: 'g [query]  → Google search' },
      ];
    },

    cls() {
      return '__CLEAR__';
    },

    exit() {
      return '__EXIT__';
    }

  };

  function openBrowser(url) {

    if (!window.WannaBrowser) {
      alert('Browser app not loaded.');
      return;
    }

    WannaBrowser.open(url);
  }

  function open() {

    let history = [];
    let histIdx = -1;

    const el = document.createElement('div');

    el.className = 'app-terminal';

    el.innerHTML = `
      <div class="term-output" id="termOut"></div>

      <div class="term-input-row">
        <span class="term-prompt">C:\\></span>
        <input
          class="term-input"
          id="termIn"
          autocomplete="off"
          spellcheck="false"
        >
      </div>
    `;

    WannaWM.open({
      id: 'terminal',
      title: '💻 WannaOS Terminal',
      icon: '💻',
      width: 700,
      height: 460,
      mount: el,
    });

    const out = el.querySelector('#termOut');
    const input = el.querySelector('#termIn');

    function printRaw(text, cls = 'out') {

      const div = document.createElement('div');

      div.className = `term-line ${cls}`;

      div.textContent = text;

      out.appendChild(div);

      out.scrollTop = out.scrollHeight;
    }

    function print(lines) {

      if (!Array.isArray(lines)) return;

      lines.forEach(l => {
        printRaw(l.v, l.t);
      });
    }

    BANNER.forEach(line => {
      printRaw(line, 'out');
    });

    input.addEventListener('keydown', (e) => {

      if (e.key === 'Enter') {

        const raw = input.value.trim();

        if (!raw) return;

        printRaw(`C:\\> ${raw}`, 'cmd');

        history.unshift(raw);

        histIdx = -1;

        input.value = '';

        const lower = raw.toLowerCase();

        // =========================
        // d query
        // =========================

        if (lower.startsWith('d ')) {

          const query = raw.slice(2).trim();

          const url =
            SEARCH_ENGINES.d +
            encodeURIComponent(query);

          printRaw(`Opening DuckDuckGo: ${query}`, 'info');

          openBrowser(url);

          return;
        }

        // =========================
        // g query
        // =========================

        if (lower.startsWith('g ')) {

          const query = raw.slice(2).trim();

          const url =
            SEARCH_ENGINES.g +
            encodeURIComponent(query);

          printRaw(`Opening Google: ${query}`, 'info');

          openBrowser(url);

          return;
        }

        // =========================
        // direct url
        // =========================

        if (
          raw.startsWith('http://') ||
          raw.startsWith('https://') ||
          raw.includes('.com') ||
          raw.includes('.org')
        ) {

          let url = raw;

          if (!url.startsWith('http')) {
            url = 'https://' + url;
          }

          printRaw(`Opening ${url}`, 'info');

          openBrowser(url);

          return;
        }

        // =========================
        // default search
        // =========================

        if (
          !COMMANDS[lower]
        ) {

          const url =
            SEARCH_ENGINES[DEFAULT_ENGINE] +
            encodeURIComponent(raw);

          printRaw(
            `Searching DuckDuckGo: ${raw}`,
            'info'
          );

          openBrowser(url);

          return;
        }

        // =========================
        // commands
        // =========================

        const result = COMMANDS[lower]();

        if (result === '__CLEAR__') {

          out.innerHTML = '';

        } else if (result === '__EXIT__') {

          WannaWM.close('terminal');

        } else {

          print(result);
        }

      }

      // =========================
      // history up/down
      // =========================

      else if (e.key === 'ArrowUp') {

        e.preventDefault();

        histIdx = Math.min(
          histIdx + 1,
          history.length - 1
        );

        input.value = history[histIdx] || '';
      }

      else if (e.key === 'ArrowDown') {

        e.preventDefault();

        histIdx = Math.max(histIdx - 1, -1);

        input.value =
          histIdx >= 0
            ? history[histIdx]
            : '';
      }
    });

    setTimeout(() => input.focus(), 100);
  }

  return { open };

})();