/**
 * WannaOS — Browser App
 */

window.WannaBrowser = (() => {

  // =========================
  // DEFAULT PAGE
  // =========================

  const DEFAULT_URL = 'https://wikipedia.org';

  // =========================
  // BOOKMARKS
  // =========================

  const BOOKMARKS = [
    {
      label: '🔒 WannaCry Info',
      url: 'https://en.wikipedia.org/wiki/WannaCry_ransomware_attack'
    },

    {
      label: '₿ Bitcoin',
      url: 'https://bitcoin.org'
    },

    {
      label: '🌐 DuckDuckGo',
      url: 'https://duckduckgo.com'
    },

    {
      label: '🔍 Google',
      url: 'https://google.com'
    },
  ];

  // =========================
  // OPEN APP
  // =========================

  function open(startUrl = DEFAULT_URL) {

    const el = document.createElement('div');

    el.className = 'app-browser';

    el.innerHTML = `

      <!-- ========================= -->
      <!-- TOOLBAR -->
      <!-- ========================= -->

      <div class="br-toolbar">

        <button class="br-btn" id="brBack">
          ◀
        </button>

        <button class="br-btn" id="brForward">
          ▶
        </button>

        <button class="br-btn" id="brRefresh">
          ↻
        </button>

        <input
          class="br-url"
          id="brUrl"
          value="${startUrl}"
          placeholder="Enter URL..."
        >

        <button
          class="br-btn"
          id="brGo"
          style="width:auto;padding:0 10px;font-size:12px;"
        >
          Go
        </button>

      </div>

      <!-- ========================= -->
      <!-- BOOKMARKS -->
      <!-- ========================= -->

      <div class="br-bookmarks">

        ${BOOKMARKS.map(b => `

          <span
            class="br-bookmark"
            data-url="${b.url}"
          >
            ${b.label}
          </span>

        `).join('')}

      </div>

      <!-- ========================= -->
      <!-- BROWSER -->
      <!-- ========================= -->

      <div class="br-browser-wrap">

        <!-- WARNING -->

        <div
          class="br-warning hidden"
          id="brWarning"
        >
          <div class="br-warning-box">

            <h2>
              🌐 External Internet Access
            </h2>

            <p>
              WannaOS Browser cannot safely
              render this website.
            </p>

            <p style="color:#ff4444">

              Opening external browser tab...

            </p>

            <button
              id="brOpenTab"
              class="dcr-btn"
            >
              OPEN IN REAL TAB
            </button>

          </div>
        </div>

        <!-- IFRAME -->

        <iframe
          class="br-iframe"
          id="brFrame"

          sandbox="
            allow-scripts
            allow-same-origin
            allow-forms
            allow-popups
            allow-popups-to-escape-sandbox
          "
        ></iframe>

      </div>

    `;

    // =========================
    // WINDOW
    // =========================

    WannaWM.open({

      id: 'browser',

      title: '🌐 Browser',

      icon: '🌐',

      width: 1000,

      height: 700,

      mount: el,
    });

    // =========================
    // ELEMENTS
    // =========================

    const frame = el.querySelector('#brFrame');

    const urlInput = el.querySelector('#brUrl');

    const warning = el.querySelector('#brWarning');

    const openTabBtn = el.querySelector('#brOpenTab');

    let currentUrl = startUrl;

    // =========================
    // NORMALIZE URL
    // =========================

    function normalize(url) {

      // search shortcut
      if (
        !url.includes('.') &&
        !url.startsWith('http')
      ) {

        return (
          'https://duckduckgo.com/?q=' +
          encodeURIComponent(url)
        );
      }

      // auto https
      if (
        !url.startsWith('http://') &&
        !url.startsWith('https://')
      ) {

        url = 'https://' + url;
      }

      return url;
    }

    // =========================
    // NAVIGATE
    // =========================

    function navigate(url) {

      url = normalize(url);

      currentUrl = url;

      urlInput.value = url;

      // =========================
      // ALLOW WIKIMEDIA
      // =========================

      if (

        url.includes('wikipedia.org') ||
        url.includes('wikimedia.org')

      ) {

        warning.classList.add('hidden');

        frame.style.display = 'block';

        frame.src = url;

        return;
      }

      // =========================
      // BLOCK OTHER SITES
      // =========================

      frame.style.display = 'none';

      warning.classList.remove('hidden');

      // auto open real tab
      setTimeout(() => {

        window.open(
          currentUrl,
          '_blank'
        );

      }, 1200);
    }

    // =========================
    // GO BUTTON
    // =========================

    el.querySelector('#brGo')

      .addEventListener('click', () => {

        navigate(
          urlInput.value.trim()
        );

      });

    // =========================
    // ENTER KEY
    // =========================

    urlInput.addEventListener('keydown', e => {

      if (e.key === 'Enter') {

        navigate(
          urlInput.value.trim()
        );
      }
    });

    // =========================
    // BACK
    // =========================

    el.querySelector('#brBack')

      .addEventListener('click', () => {

        try {

          frame.contentWindow.history.back();

        } catch(e) {}

      });

    // =========================
    // FORWARD
    // =========================

    el.querySelector('#brForward')

      .addEventListener('click', () => {

        try {

          frame.contentWindow.history.forward();

        } catch(e) {}

      });

    // =========================
    // REFRESH
    // =========================

    el.querySelector('#brRefresh')

      .addEventListener('click', () => {

        frame.src = frame.src;

      });

    // =========================
    // BOOKMARKS
    // =========================

    el.querySelectorAll('.br-bookmark')

      .forEach(btn => {

        btn.addEventListener('click', () => {

          navigate(
            btn.dataset.url
          );

        });

      });

    // =========================
    // OPEN REAL TAB
    // =========================

    openTabBtn.addEventListener('click', () => {

      window.open(
        currentUrl,
        '_blank'
      );

    });

    // =========================
    // START PAGE
    // =========================

    navigate(startUrl);
  }

  return { open };

})();