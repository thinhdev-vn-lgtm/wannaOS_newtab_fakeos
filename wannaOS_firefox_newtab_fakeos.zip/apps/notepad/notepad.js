/**
 * WannaOS — Notepad App
 */

window.WannaNotepad = (() => {
  const NP_KEY = 'wannaos_notepad';

  function open(initialContent = null) {
    const savedContent = initialContent ?? localStorage.getItem(NP_KEY) ?? '';
    let isDirty = false;

    const el = document.createElement('div');
    el.className = 'app-notepad';
    el.innerHTML = `
      <div class="np-toolbar">
        <div class="np-menu" id="npFile">File ▾</div>
        <div class="np-menu" id="npEdit">Edit ▾</div>
        <div class="np-menu" id="npFormat">Format ▾</div>
      </div>
      <textarea class="np-textarea" id="npText" spellcheck="false" placeholder="Start typing...">${savedContent}</textarea>
      <div class="np-status" id="npStatus">Ln 1, Col 1 | Autosave: ON | WannaOS Notepad</div>
    `;

    WannaWM.open({
      id: 'notepad',
      title: '📝 Notepad',
      icon: '📝',
      width: 560,
      height: 400,
      mount: el,
    });

    const textarea = el.querySelector('#npText');
    const status   = el.querySelector('#npStatus');

    // Autosave
    let saveTimeout;
    textarea.addEventListener('input', () => {
      isDirty = true;
      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(() => {
        localStorage.setItem(NP_KEY, textarea.value);
        isDirty = false;
        updateStatus('Autosaved ✓');
      }, 1500);
      updateStatus('Unsaved changes...');
    });

    // Cursor position
    textarea.addEventListener('keyup', updateCursor);
    textarea.addEventListener('click', updateCursor);

    function updateCursor() {
      const val = textarea.value.substr(0, textarea.selectionStart);
      const lines = val.split('\n');
      const ln = lines.length;
      const col = lines[lines.length - 1].length + 1;
      status.textContent = `Ln ${ln}, Col ${col} | WannaOS Notepad`;
    }

    function updateStatus(msg) {
      status.textContent = msg;
      setTimeout(updateCursor, 2000);
    }

    // File menu
    el.querySelector('#npFile').addEventListener('click', () => {
      const action = prompt('File menu:\n1. New\n2. Save\n3. Close\n\nEnter number:');
      if (action === '1') { textarea.value = ''; localStorage.removeItem(NP_KEY); }
      if (action === '2') { localStorage.setItem(NP_KEY, textarea.value); updateStatus('Saved!'); }
      if (action === '3') { WannaWM.close('notepad'); }
    });

    setTimeout(() => textarea.focus(), 100);
  }

  return { open };
})();
