/**
 * WannaOS — WannaDecryptor App
 */

window.WannaSearchEngine = 'duckduckgo';

window.WannaDecryptor = (() => {

  let timerInterval = null;
  let totalSeconds = 0;

  function buildUI() {

    const el = document.createElement('div');
    el.className = 'app-decryptor';

    const ransomAmount =
      parseInt(localStorage.getItem('wos_ransom')) || 300;

    totalSeconds =
      parseInt(localStorage.getItem('wos_timer')) || 10 * 60;

    el.innerHTML = `
      <div class="dcr-header">
        <div class="dcr-skull">💀</div>

        <div class="dcr-title">
          WANA SEARCH 2.0
        </div>

        <div class="dcr-sub">
          YOUR IMPORTANT FILES ARE INDEXED
        </div>
      </div>

      <div class="dcr-body">

        <div class="dcr-left">

          <div class="dcr-panel">
            <div class="dcr-panel-title">
              ⚠️ Payment Deadline
            </div>

            <div
              style="
                font-size:10px;
                color:#882222;
                margin-bottom:6px;
              "
            >
              Price doubles in:
            </div>

            <div
              class="dcr-clock"
              id="dcrClock"
            >
              00:00:00
            </div>
          </div>

          <div class="dcr-panel">

            <div class="dcr-panel-title">
              ☠️ File Destruction
            </div>

            <div
              style="
                font-size:10px;
                color:#882222;
                margin-bottom:6px;
              "
            >
              Files deleted in:
            </div>

            <div
              class="dcr-clock"
              id="dcrDestClock"
            >
              06:00:00
            </div>

          </div>

          <div class="dcr-panel">

            <div class="dcr-panel-title">
              📊 Encryption
            </div>

            <div class="dcr-bar-wrap">
              <div
                class="dcr-bar-fill"
                style="width:100%"
              ></div>
            </div>

            <div
              style="
                font-size:10px;
                color:#882222;
                margin-top:4px;
              "
            >
              1,289 files encrypted
            </div>

          </div>

          <div
            class="dcr-ransom"
            id="dcrRansom"
          >
            $${ransomAmount} worth of Bitcoin
          </div>

        </div>

        <div class="dcr-right">

          <div class="dcr-big-msg">

            <div
              style="
                color:#ff0000;
                font-size:14px;
                font-weight:bold;
                margin-bottom:8px;
              "
            >
              ⚠ Ooops, your important files are encrypted!
            </div>

            Search the internet before your files are gone forever.

            <br><br>

            Wikimedia can help save your files.
            Use DuckDuckGo or Google to search safely.

            <br><br>

            Default search engine:
            <span
              id="searchEngineLabel"
              style="color:#ff0000"
            >
              DuckDuckGo
            </span>

            <br><br>

            Terminal commands:
            <br>

            <span style="color:#ffaa00">d</span>
            = DuckDuckGo

            <br>

            <span style="color:#ffaa00">g</span>
            = Google

          </div>

          <div class="dcr-panel">

            <div class="dcr-panel-title">
              🔎 Search Engine
            </div>

            <div
              style="
                display:flex;
                gap:8px;
                margin-bottom:8px;
              "
            >

              <input
                class="dcr-input"
                id="dcrSearchInput"
                placeholder="Search the web..."
                style="flex:1"
              >

              <button
                class="dcr-btn"
                id="dcrSearchBtn"
                style="
                  width:auto;
                  padding:8px 16px;
                  font-size:11px;
                "
              >
                SEARCH
              </button>

            </div>

            <div
              id="dcrSearchMsg"
              style="
                font-size:11px;
                color:#882222;
                min-height:16px;
              "
            >
              Engine ready.
            </div>

          </div>

          <div class="dcr-panel">

            <div class="dcr-panel-title">
              ℹ️ System Info
            </div>

            <div class="dcr-info-row">
              <span>Hostname</span>
              <span>INFECTED-PC</span>
            </div>

            <div class="dcr-info-row">
              <span>Encrypted Files</span>
              <span>1,289</span>
            </div>

            <div class="dcr-info-row">
              <span>Algorithm</span>
              <span>RSA-2048 + AES-128</span>
            </div>

            <div class="dcr-info-row">
              <span>Search Engine</span>

              <span id="searchEngineInfo">
                DuckDuckGo
              </span>
            </div>

            <div class="dcr-info-row">
              <span>Status</span>

              <span style="color:#ff0000">
                LOCKED
              </span>
            </div>

          </div>

        </div>

      </div>

      <div class="dcr-footer">

        <span class="dcr-warn-blink">
          ⚠ YOUR FILES ARE ENCRYPTED
        </span>

        <span>
          WannaCry 2.0 — Ransomware as a Service
        </span>

      </div>
    `;

    return el;
  }

  function open() {

    const el = buildUI();

    WannaWM.open({
      id: 'decryptor',
      title: '🔒 Wana Search 2.0',
      icon: '🔒',
      width: 760,
      height: 520,
      mount: el,

      onclose() {
        stopTimer();
      },
    });

    startTimer();

    setupSearch(el);

    updateEngineUI();
  }

  function updateEngineUI() {

    const label =
      document.getElementById('searchEngineLabel');

    const info =
      document.getElementById('searchEngineInfo');

    const name =
      window.WannaSearchEngine === 'google'
        ? 'Google'
        : 'DuckDuckGo';

    if (label) {
      label.textContent = name;
    }

    if (info) {
      info.textContent = name;
    }
  }

  function setupSearch(el) {

    const input =
      el.querySelector('#dcrSearchInput');

    const btn =
      el.querySelector('#dcrSearchBtn');

    const msg =
      el.querySelector('#dcrSearchMsg');

    function search() {

      const q = input.value.trim();

      if (!q) {

        msg.textContent =
          'Please enter a search query.';

        return;
      }

      let url = '';

      if (window.WannaSearchEngine === 'google') {

        url =
          'https://www.google.com/search?q=' +
          encodeURIComponent(q);

      } else {

        url =
          'https://duckduckgo.com/?q=' +
          encodeURIComponent(q);
      }

      msg.textContent =
        'Searching with ' +
        window.WannaSearchEngine +
        '...';

      if (
        window.WannaBrowser &&
        typeof WannaBrowser.openUrl === 'function'
      ) {

        WannaBrowser.openUrl(url);

      } else {

        window.open(url, '_blank');
      }
    }

    btn.addEventListener('click', search);

    input.addEventListener('keydown', (e) => {

      if (e.key === 'Enter') {
        search();
      }
    });
  }

  function startTimer() {

    stopTimer();

    let destSeconds = 6 * 3600;

    timerInterval = setInterval(() => {

      totalSeconds =
        Math.max(0, totalSeconds - 1);

      destSeconds =
        Math.max(0, destSeconds - 1);

      localStorage.setItem(
        'wos_timer',
        totalSeconds
      );

      const clock =
        document.getElementById('dcrClock');

      const destClock =
        document.getElementById('dcrDestClock');

      if (clock) {

        clock.textContent =
          formatTime(totalSeconds);
      }

      if (destClock) {

        destClock.textContent =
          formatTime(destSeconds);
      }

    }, 1000);
  }

  function stopTimer() {

    if (timerInterval) {

      clearInterval(timerInterval);

      timerInterval = null;
    }
  }

  function formatTime(secs) {

    const h =
      String(
        Math.floor(secs / 3600)
      ).padStart(2, '0');

    const m =
      String(
        Math.floor((secs % 3600) / 60)
      ).padStart(2, '0');

    const s =
      String(secs % 60)
      .padStart(2, '0');

    return h + ':' + m + ':' + s;
  }

  return {
    open,
    updateEngineUI,
  };

})();