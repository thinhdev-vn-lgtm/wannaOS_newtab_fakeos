/**
 * WannaOS — Desktop Manager
 */

window.WannaDesktop = (() => {
  const ICONS = [
    { id: 'decryptor', label: 'WannaDecryptor\n2.0', icon: '🔒', action: () => WannaOS.apps.openApp('decryptor') },
    { id: 'explorer',  label: 'File Explorer',       icon: '📁', action: () => WannaOS.apps.openApp('explorer') },
    { id: 'terminal',  label: 'Terminal',             icon: '💻', action: () => WannaOS.apps.openApp('terminal') },
    { id: 'notepad',   label: 'Notepad',              icon: '📝', action: () => WannaOS.apps.openApp('notepad') },
    { id: 'browser',   label: 'Browser',              icon: '🌐', action: () => WannaOS.apps.openApp('browser') },
    { id: 'readme',    label: 'README.txt',           icon: '📄', action: () => WannaOS.apps.openReadme() },
    { id: 'decrypt',   label: 'decrypt.exe',          icon: '⚙️', action: () => WannaOS.apps.openApp('decryptor') },
  ];

  const wallpapers = [
    'linear-gradient(135deg, #050000 0%, #0a0000 50%, #030000 100%)',
    'radial-gradient(ellipse at center, #1a0000 0%, #000 70%)',
    'linear-gradient(45deg, #000 0%, #0a0200 50%, #000 100%)',
  ];
  let wallpaperIdx = 0;
  let selectedIcon = null;

  function init() {
    renderIcons();
    setupContextMenu();
  }

  function renderIcons() {
    const container = document.getElementById('desktopIcons');
    container.innerHTML = '';

    ICONS.forEach(def => {
      const el = document.createElement('div');
      el.className = 'desktop-icon';
      el.id = `dicon_${def.id}`;
      el.innerHTML = `
        <div class="icon-img">${def.icon}</div>
        <div class="icon-label">${def.label}</div>
      `;

      el.addEventListener('click', (e) => {
        e.stopPropagation();
        selectIcon(el);
      });

      el.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        def.action();
        selectIcon(null);
      });

      container.appendChild(el);
    });

    // Deselect on desktop click
    document.getElementById('desktop').addEventListener('click', (e) => {
      if (e.target === document.getElementById('desktop') ||
          e.target.classList.contains('crt-overlay') ||
          e.target.classList.contains('scanlines')) {
        selectIcon(null);
        hideContextMenu();
      }
    });
  }

  function selectIcon(el) {
    if (selectedIcon) selectedIcon.classList.remove('selected');
    selectedIcon = el;
    if (el) el.classList.add('selected');
  }

  function setupContextMenu() {
    const desktop = document.getElementById('desktop');
    const ctx = document.getElementById('contextMenu');

    desktop.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      ctx.style.left = Math.min(e.clientX, window.innerWidth - 210) + 'px';
      ctx.style.top = Math.min(e.clientY, window.innerHeight - 200) + 'px';
      ctx.classList.remove('hidden');
    });

    document.addEventListener('click', () => hideContextMenu());
    document.addEventListener('contextmenu', () => {
      // Re-position handled above
    });
  }

  function hideContextMenu() {
    document.getElementById('contextMenu')?.classList.add('hidden');
  }

  function changeWallpaper() {
    wallpaperIdx = (wallpaperIdx + 1) % wallpapers.length;
    document.getElementById('desktop').style.background = wallpapers[wallpaperIdx];
  }

  return { init, renderIcons, changeWallpaper };
})();
