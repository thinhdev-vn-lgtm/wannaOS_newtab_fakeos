document.addEventListener('DOMContentLoaded', () => {

  if (
    window.WannaOS &&
    WannaOS.boot &&
    typeof WannaOS.boot.start === 'function'
  ) {
    WannaOS.boot.start();
  }

  // START BUTTON
  const startBtn = document.getElementById('startBtn');

  if (startBtn) {

    startBtn.addEventListener('click', () => {

      if (
        window.WannaOS &&
        WannaOS.taskbar &&
        typeof WannaOS.taskbar.toggleStart === 'function'
      ) {

        WannaOS.taskbar.toggleStart();
      }
    });
  }

  // START MENU APPS
  document.querySelectorAll('[data-app]')
    .forEach(el => {

      el.addEventListener('click', () => {

        const app = el.dataset.app;

        if (
          window.WannaOS &&
          WannaOS.apps &&
          typeof WannaOS.apps.openApp === 'function'
        ) {

          WannaOS.apps.openApp(app);
        }

        // auto close start menu
        const sm = document.getElementById('startMenu');

        if (sm) {
          sm.classList.add('hidden');
        }
      });
    });

});