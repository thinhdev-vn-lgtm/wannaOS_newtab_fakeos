/**
 * WannaOS — Fake Filesystem
 * Uses localStorage for persistence
 */

window.WannaFS = (() => {
  const FS_KEY = 'wannaos_fs';

  const DEFAULT_FS = {
    'C:': {
      type: 'dir',
      children: {
        'Desktop': { type: 'dir', children: {
          'README.txt':       { type: 'file', content: 'YOUR FILES ARE ENCRYPTED.\nPay $300 worth of Bitcoin to decrypt.\nDo not delete this file.' },
          'decrypt.exe':      { type: 'file', content: '[BINARY]' },
          'HOW_TO_DECRYPT.txt':{ type: 'file', content: 'Instructions:\n1. Buy Bitcoin\n2. Send to wallet\n3. Email proof\n4. Get key\n\nBitcoin Address: 1A2b3C4d5E6f7G8h9I0j' },
        }},
        'Documents': { type: 'dir', children: {
          'passwords.txt':    { type: 'file', content: 'admin:admin123\nroot:toor\nuser:12345678' },
          'bank_info.txt':    { type: 'file', content: 'Account: ****4521\nRouting: ****8823\n[ENCRYPTED]' },
          'work_notes.txt':   { type: 'file', content: 'Meeting at 3pm\nProject deadline: Friday\nCall back John' },
        }},
        'System32': { type: 'dir', children: {
          'kernel32.dll':   { type: 'file', content: '[SYSTEM BINARY]' },
          'ntdll.dll':      { type: 'file', content: '[SYSTEM BINARY]' },
          'cmd.exe':        { type: 'file', content: '[EXECUTABLE]' },
          'taskmgr.exe':    { type: 'file', content: '[EXECUTABLE]' },
          'regedit.exe':    { type: 'file', content: '[EXECUTABLE]' },
          'wannacry.dll':   { type: 'file', content: '[PAYLOAD — DO NOT DELETE]' },
        }},
        'Users': { type: 'dir', children: {
          'INFECTED-PC': { type: 'dir', children: {
            'AppData':    { type: 'dir', children: {} },
            'Downloads':  { type: 'dir', children: {
              'free_game.exe': { type: 'file', content: '[INFECTED BINARY]' },
            }},
            'Pictures':   { type: 'dir', children: {} },
          }},
        }},
        'Windows': { type: 'dir', children: {
          'System':   { type: 'dir', children: {} },
          'Temp':     { type: 'dir', children: {} },
          'Logs':     { type: 'dir', children: {
            'infection.log': { type: 'file', content: '[2017-05-12 09:43:22] WannaCry payload executed\n[2017-05-12 09:43:25] Scanning network...\n[2017-05-12 09:43:30] Found 14 vulnerable machines\n[2017-05-12 09:43:45] Encrypting files... done\n[2017-05-12 09:44:01] Displaying ransom note' },
          }},
        }},
        'WNCRYPT':  { type: 'dir', children: {
          '00000001.res': { type: 'file', content: '[ENCRYPTED]' },
          '00000002.res': { type: 'file', content: '[ENCRYPTED]' },
          't.wnry':       { type: 'file', content: '[TOR PAYLOAD]' },
          'u.wnry':       { type: 'file', content: '[UNLOCKER — NEEDS KEY]' },
        }},
      }
    }
  };

  let _fs = null;

  function load() {
    const saved = localStorage.getItem(FS_KEY);
    _fs = saved ? JSON.parse(saved) : JSON.parse(JSON.stringify(DEFAULT_FS));
  }

  function save() {
    localStorage.setItem(FS_KEY, JSON.stringify(_fs));
  }

  function reset() {
    _fs = JSON.parse(JSON.stringify(DEFAULT_FS));
    save();
  }

  // Navigate to a path, returns the node or null
  function navigate(path) {
    const parts = path.replace(/\\/g, '/').split('/').filter(Boolean);
    let node = _fs;
    for (const part of parts) {
      if (!node[part] && !node.children?.[part]) return null;
      node = node[part] || node.children[part];
    }
    return node;
  }

  function ls(path) {
    const node = navigate(path);
    if (!node || node.type !== 'dir') return null;
    return Object.entries(node.children).map(([name, n]) => ({
      name, type: n.type,
      icon: n.type === 'dir' ? '📁' : getFileIcon(name),
    }));
  }

  function read(path) {
    const node = navigate(path);
    if (!node || node.type !== 'file') return null;
    return node.content;
  }

  function write(path, content) {
    const parts = path.replace(/\\/g, '/').split('/').filter(Boolean);
    const name = parts.pop();
    const parent = navigate(parts.join('/'));
    if (!parent || parent.type !== 'dir') return false;
    parent.children[name] = { type: 'file', content };
    save();
    return true;
  }

  function getFileIcon(name) {
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
      txt: '📄', exe: '⚙️', dll: '🔧', log: '📋',
      jpg: '🖼️', png: '🖼️', mp3: '🎵',
      zip: '📦', rar: '📦',
    };
    return icons[ext] || '📄';
  }

  load();

  return { ls, read, write, reset, navigate, getFileIcon };
})();
