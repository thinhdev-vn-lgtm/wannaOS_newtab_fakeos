/**
 * WannaOS — App Registry & Launcher
 */

window.WannaApps = (() => {
  const registry = {};

  function register(id, def) { registry[id] = def; }

  function openApp(id) {
    if (!registry[id]) { console.warn('App not found:', id); return; }
    registry[id].open();
  }

  function openReadme() {
    const content = WannaFS.read('C:/Desktop/README.txt');
    const el = document.createElement('div');
    el.style.cssText = 'height:100%;display:flex;flex-direction:column;background:#0d0000;';
    el.innerHTML = `
      <div style="padding:4px 8px;background:#0a0000;border-bottom:1px solid #330000;font-size:11px;color:#882222;font-family:var(--font-mono)">
        <span style="cursor:pointer;padding:2px 8px;color:#cc4444;" onclick="">File</span>
        <span style="cursor:pointer;padding:2px 8px;color:#cc4444;" onclick="">Edit</span>
      </div>
      <textarea readonly style="flex:1;background:#000;color:#ff4444;border:none;outline:none;padding:12px;font-family:'Share Tech Mono',monospace;font-size:13px;resize:none;line-height:1.7">${content}</textarea>
    `;
    WannaWM.open({ id: 'readme', title: '📄 README.txt — Notepad', icon: '📄', width: 500, height: 340, mount: el });
  }

  return { register, openApp, openReadme };
})();
