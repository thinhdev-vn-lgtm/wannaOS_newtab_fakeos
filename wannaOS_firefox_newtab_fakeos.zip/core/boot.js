window.WannaOS = window.WannaOS || {
  boot: null,
  taskbar: null,
  desktop: null,
  apps: null,
  wm: null,

  notify(title, body, duration = 4000) {
    const area = document.getElementById('notifArea');
    if (!area) return;

    const el = document.createElement('div');
    el.className = 'notif';

    el.innerHTML = `
      <div class="notif-title">
        <span class="notif-close">✕</span>
        ${title}
      </div>
      <div>${body}</div>
    `;

    el.querySelector('.notif-close').onclick = () => el.remove();

    area.prepend(el);

    setTimeout(() => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    }, duration);
  },

  triggerBSOD() {
    const bsod = document.getElementById('bsodScreen');
    const pct = document.getElementById('bsodPct');
    if (!bsod || !pct) return;

    bsod.classList.remove('hidden');

    let n = 0;
    const t = setInterval(() => {
      n += Math.floor(Math.random() * 8) + 1;
      if (n >= 100) {
        n = 100;
        clearInterval(t);
      }
      pct.textContent = `Dumping physical memory to disk: ${n}`;
    }, 120);

    setTimeout(() => {
      bsod.classList.add('hidden');
      WannaOS.notify('💥 BSOD Recovered', 'System recovered.', 4000);
    }, 8000);
  }
};

// ===== BOOT SYSTEM =====
WannaOS.boot = (() => {

  const STEPS = [
    { pct: 8, text: 'Initializing kernel...' },
    { pct: 18, text: 'Loading system...' },
    { pct: 28, text: 'Checking modules...' },
    { pct: 42, text: 'Starting services...' },
    { pct: 55, text: 'Preparing desktop...' },
    { pct: 76, text: 'Loading UI...' },
    { pct: 92, text: 'Almost ready...' },
    { pct: 100, text: 'Done.' },
  ];

  function start() {
    // delay để DOM chắc chắn load
    setTimeout(init, 200);
  }

  function init() {
    const safe = (obj) => typeof obj !== "undefined";

    if (safe(WannaTaskbar)) WannaOS.taskbar = WannaTaskbar;
    if (safe(WannaDesktop)) WannaOS.desktop = WannaDesktop;
    if (safe(WannaApps)) WannaOS.apps = WannaApps;
    if (safe(WannaWM)) WannaOS.wm = WannaWM;

    if (WannaApps?.register) {
      WannaApps.register('decryptor', { open: WannaDecryptor?.open });
      WannaApps.register('terminal', { open: WannaTerminal?.open });
      WannaApps.register('explorer', { open: WannaExplorer?.open });
      WannaApps.register('notepad', { open: WannaNotepad?.open });
      WannaApps.register('browser', { open: WannaBrowser?.open });
    }

    runBoot(0);
  }

  function runBoot(i) {
    const fill = document.getElementById('bootFill');
    const status = document.getElementById('bootStatus');

    if (!fill || !status) return;

    if (i >= STEPS.length) return finish();

    const step = STEPS[i];
    fill.style.width = step.pct + '%';
    status.textContent = step.text;

    setTimeout(() => runBoot(i + 1), 250);
  }

  function finish() {
    const boot = document.getElementById('bootScreen');
    const desktop = document.getElementById('desktop');

    if (!boot || !desktop) return;

    boot.style.opacity = '0';

    setTimeout(() => {
      boot.classList.add('hidden');
      desktop.classList.remove('hidden');

      WannaTaskbar?.init?.();
      WannaDesktop?.init?.();

      setTimeout(() => WannaApps?.openApp?.('decryptor'), 600);

      WannaOS.notify('🦠 System Active', 'FakeOS started successfully', 4000);

    }, 500);
  }

  return { start };
})();