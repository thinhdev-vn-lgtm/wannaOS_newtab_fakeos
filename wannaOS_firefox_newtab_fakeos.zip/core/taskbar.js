/**
 * WannaOS — Taskbar Manager
 */

window.WannaTaskbar = (() => {
  const apps = new Map(); // id → { el, icon, title }
  let startOpen = false;

  function init() {
    // Realtime clock
    updateClock();
    setInterval(updateClock, 1000);

    // Close start menu on outside click
    document.addEventListener('click', (e) => {
      const sm = document.getElementById('startMenu');
      const sb = document.getElementById('startBtn');
      if (!sm.contains(e.target) && !sb.contains(e.target)) {
        sm.classList.add('hidden');
        startOpen = false;
      }
    });
  }

  function updateClock() {
    const el = document.getElementById('trayClock');
    if (!el) return;
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const d = now.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
    el.innerHTML = `${h}:${m}<br><span style="font-size:9px;opacity:.7">${d}</span>`;
  }

  function addApp(id, icon, title) {
    const container = document.getElementById('taskbarApps');
    if (!container || apps.has(id)) return;

    const btn = document.createElement('button');
    btn.className = 'tb-app active';
    btn.innerHTML = `<span>${icon}</span><span class="tb-title">${title}</span>`;
    btn.title = title;
    btn.addEventListener('click', () => {
      const wb = WannaWM.get(id);
      if (!wb) return;
      if (btn.classList.contains('active')) {
        wb.minimize();
      } else {
        wb.restore ? wb.restore() : wb.focus();
        btn.classList.add('active');
      }
    });

    container.appendChild(btn);
    apps.set(id, { el: btn, icon, title });
  }

  function removeApp(id) {
    if (!apps.has(id)) return;
    apps.get(id).el.remove();
    apps.delete(id);
  }

  function setActive(id, active) {
    if (!apps.has(id)) return;
    apps.get(id).el.classList.toggle('active', active);
  }

  function toggleStart() {
    const sm = document.getElementById('startMenu');
    startOpen = !startOpen;
    sm.classList.toggle('hidden', !startOpen);
  }

  return { init, addApp, removeApp, setActive, toggleStart, updateClock };
})();
