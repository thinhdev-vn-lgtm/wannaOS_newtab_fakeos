/**
 * WannaOS — Window Manager (WinBox wrapper)
 */

window.WannaWM = (() => {
  const openWindows = new Map(); // id → WinBox instance

  // Default WinBox config with WannaCry theme
  const DEFAULTS = {
    class: 'wannacry-theme',
    width: 700,
    height: 460,
    x: 'center',
    y: 'center',
    minwidth: 320,
    minheight: 200,
    border: 4,
  };

  function open(config) {
    const id = config.id || `win_${Date.now()}`;

    // If already open, focus it
    if (openWindows.has(id)) {
      openWindows.get(id).focus();
      return openWindows.get(id);
    }

    // Cascade offset so windows don't stack
    const offset = openWindows.size * 28;

    const wb = new WinBox({
      ...DEFAULTS,
      ...config,
      id,
      x: typeof config.x !== 'undefined' ? config.x : Math.max(60, 80 + offset),
      y: typeof config.y !== 'undefined' ? config.y : Math.max(30, 40 + offset),
      onclose() {
        openWindows.delete(id);
        WannaOS.taskbar.removeApp(id);
        if (config.onclose) config.onclose();
        return false; // let WinBox handle
      },
      onminimize() {
        WannaOS.taskbar.setActive(id, false);
        if (config.onminimize) config.onminimize();
      },
      onfocus() {
        WannaOS.taskbar.setActive(id, true);
        if (config.onfocus) config.onfocus();
      },
      onblur() {
        WannaOS.taskbar.setActive(id, false);
        if (config.onblur) config.onblur();
      },
    });

    openWindows.set(id, wb);

    // Add to taskbar
    WannaOS.taskbar.addApp(id, config.icon || '🪟', config.title || 'App');

    return wb;
  }

  function close(id) {
    if (openWindows.has(id)) {
      openWindows.get(id).close();
      openWindows.delete(id);
    }
  }

  function focus(id) {
    if (openWindows.has(id)) {
      openWindows.get(id).focus();
    }
  }

  function getAll() { return [...openWindows.keys()]; }
  function get(id) { return openWindows.get(id); }

  return { open, close, focus, getAll, get };
})();
